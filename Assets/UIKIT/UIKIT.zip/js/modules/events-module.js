﻿
//////// run charts

window.onload = function () {
    $.ajax({
        type: "POST",
        url: "/AjexServer/ajexresponse.aspx/BindEvenets",
        data: "{}",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            //alert(data.d);
            var jsdata = JSON.parse(data.d);
            var calendarEl = document.getElementById('calendar');
            var date = new Date();
            var d = date.getDate();
            if (d  < 10) {
                d = '0' + d;
            }
            var m = date.getMonth() + 1;
            if (m < 10) {
                m = '0' + m;
            }
            var y = date.getFullYear();
            var options = {
                weekday: "long", year: "numeric", month: "short",
                day: "numeric", hour: "2-digit", minute: "2-digit"
            };
            var cdate = y + '-' + m + '-' + d;
            var calendar = new FullCalendar.Calendar(calendarEl, {
                initialDate: cdate,
                locale: lang,
                initialView: 'dayGridMonth',
                headerToolbar: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'dayGridMonth,timeGridWeek,timeGridDay'
                },
                height: 'auto',
                navLinks: true, // can click day/week names to navigate views
                editable: true,
                selectable: true,
                selectMirror: true,
                nowIndicator: true,
                events: jsdata,
                eventAfterRender: function (event, element, view) {
                    element.css('background-color', '#FFB347');
                },
            });
            calendar.render();
        },
        error: function (result) {
            // alert("Error");
        }
    });
    //var calendarEl = document.getElementById('calendar');

    //var calendar = new FullCalendar.Calendar(calendarEl, {
    //    initialDate: '2020-06-12',
    //    initialView: 'dayGridMonth',
    //    headerToolbar: {
    //        left: 'prev,next today',
    //        center: 'title',
    //        right: 'dayGridMonth,timeGridWeek,timeGridDay'
    //    },
    //    height: 'auto',
    //    navLinks: true, // can click day/week names to navigate views
    //    editable: true,
    //    selectable: true,
    //    selectMirror: true,
    //    nowIndicator: true,
    //    events: [
    //        {
    //            title: 'All Day Event',
    //            start: '2020-06-01',
    //            color:'#000'
    //        },
    //        {
    //            title: 'Long Event',
    //            start: '2020-06-07',
    //            end: '2020-06-10'
    //            ,color: '#000'
    //        },
    //        {
    //            groupId: 999,
    //            title: 'Repeating Event',
    //            start: '2020-06-09T16:00:00'
    //            , color: '#000'
    //        },
    //        {
    //            groupId: 999,
    //            title: 'Repeating Event',
    //            start: '2020-06-16T16:00:00'
    //             ,color: '#000'
    //        },
    //        {
    //            title: 'Conference',
    //            start: '2020-06-11',
    //            end: '2020-06-13'
    //            , color: '#000'
    //        },
    //        {
    //            title: 'Meeting',
    //            start: '2020-06-12T10:30:00',
    //            end: '2020-06-12T12:30:00'
    //            , color: '#000'
    //        },
    //        {
    //            title: 'Lunch',
    //            start: '2020-06-12T12:00:00'
    //        },
    //        {
    //            title: 'Meeting',
    //            start: '2020-06-12T14:30:00'
    //        },
    //        {
    //            title: 'Happy Hour',
    //            start: '2020-06-12T17:30:00'
    //        },
    //        {
    //            title: 'Dinner',
    //            start: '2020-06-12T20:00:00'
    //        },
    //        {
    //            title: 'Birthday Party',
    //            start: '2020-06-13T07:00:00'
    //        },
    //        {
    //            title: 'Click for Google',
    //            url: 'http://google.com/',
    //            start: '2020-06-28'
    //        }
    //    ]
    //});

    //calendar.render();
};

