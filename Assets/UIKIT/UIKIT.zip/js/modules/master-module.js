﻿//page load
$(function () {
    loadNotification();
    loadInbox();
})
function loadNotification() {
    $.ajax({
        type: "POST",
        url: "/AjexServer/ajexresponse.aspx/GetNewNotifications",
        data: "{}",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            var jsdata = JSON.parse(data.d);
            var html = "";
            for (var i = 0; i < jsdata.length; i++) {
                html += "                                                <div class=\"avatar\" data-id='" + jsdata[i].Id + "' style='overflow: inherit!important'>";
                html += "                                                    <img src=\"/Assets/UIKIT/img/bell.png\" class=\"bg-cover \" >";
                html += "                                                <\/div>";
                html += "                                                <p class=\"msg\">" + jsdata[i].Name;
                //html += "                                                    <span class=\"remove-item";
                //html += "                                            \">";
                //html += "                                                <svg xmlns=\"http:\/\/www.w3.org\/2000\/svg\" width=\"11.963\" height=\"11.963\"";
                //html += "                                                    viewBox=\"0 0 11.963 11.963\">";
                //html += "                                                    <g id=\"Group_21\" data-name=\"Group 21\"";
                //html += "                                                        transform=\"translate(5.981 -3.153) rotate(45)\">";
                //html += "                                                        <line id=\"Line_28\" data-name=\"Line 28\" y2=\"12.918\"";
                //html += "                                                            transform=\"translate(6.459)\" fill=\"none\" stroke=\"#fff\"";
                //html += "                                                            stroke-linecap=\"round\" stroke-width=\"2\">";
                //html += "                                                        <\/line>";
                //html += "                                                        <line id=\"Line_29\" data-name=\"Line 29\" x2=\"12.918\"";
                //html += "                                                            transform=\"translate(0 6.459)\" fill=\"none\" stroke=\"#fff\"";
                //html += "                                                            stroke-linecap=\"round\" stroke-width=\"2\">";
                //html += "                                                        <\/line>";
                //html += "                                                    <\/g>";
                //html += "                                                <\/svg><\/span>";
                html += "                                                <\/p>";
                html += "                                                <p class=\"info\">";
                html += "                                                    <span class=\"group\">";
                html += "                                                        <svg xmlns=\"http:\/\/www.w3.org\/2000\/svg\"";
                html += "                                                            id=\"Group_1787\" data-name=\"Group 1787\" width=\"27.34\" height=\"22.534\"";
                html += "                                                            viewBox=\"0 0 27.34 22.534\">";
                html += "                                                            <path id=\"Path_6934\" data-name=\"Path 6934\"";
                html += "                                                                d=\"M255.352,77.4h11.835a.41.41,0,0,0,.41-.41V75.41a.41.41,0,0,0-.41-.41H254.222a.41.41,0,0,0-.334.649l1.13,1.582A.411.411,0,0,0,255.352,77.4Z\"";
                html += "                                                                transform=\"translate(-240.258 -73.398)\" fill=\"#484848\">";
                html += "                                                            <\/path>";
                html += "                                                            <path id=\"Path_6935\" data-name=\"Path 6935\"";
                html += "                                                                d=\"M8.909,45H2.225A2.225,2.225,0,0,0,0,47.225V65.31a2.225,2.225,0,0,0,2.225,2.225H25.116A2.225,2.225,0,0,0,27.34,65.31V52.832a2.225,2.225,0,0,0-2.225-2.225H15.2a2.225,2.225,0,0,1-1.81-.932l-2.674-3.744A2.225,2.225,0,0,0,8.909,45Z\"";
                html += "                                                                transform=\"translate(0 -45)\" fill=\"#484848\">";
                html += "                                                            <\/path>";
                html += "                                                        <\/svg><\/span><span class=\"time\"><svg xmlns=\"http:\/\/www.w3.org\/2000\/svg\"";
                html += "                                                            id=\"Group_2143\" data-name=\"Group 2143\" width=\"19\" height=\"19\"";
                html += "                                                            viewBox=\"0 0 19 19\">";
                html += "                                                            <path id=\"Path_6985\" data-name=\"Path 6985\"";
                html += "                                                                d=\"M9.5,0A9.5,9.5,0,1,0,19,9.5,9.511,9.511,0,0,0,9.5,0Zm0,17.812A8.312,8.312,0,1,1,17.812,9.5,8.322,8.322,0,0,1,9.5,17.812Z\"";
                html += "                                                                fill=\"#484848\">";
                html += "                                                            <\/path>";
                html += "                                                            <path id=\"Path_6986\" data-name=\"Path 6986\"";
                html += "                                                                d=\"M241.187,96H240v6.183l3.736,3.736.84-.84-3.388-3.388Z\"";
                html += "                                                                transform=\"translate(-231.094 -92.438)\" fill=\"#484848\">";
                html += "                                                            <\/path>";
                html += "                                                        <\/svg>";
                html += "                                                            8س<\/span>";
                html += "                                                <\/p>";
                html += "                                            <\/div>";

            }
            if (jsdata.length == 0) {
                if (lang == 'ar') {
                    html += "                                                <div class=\"avatar\" >";
                    html += "                                                    <img src=\"img\/icon-nav-user.png\" class=\"bg-cover \">";
                    html += "                                                <\/div>";
                    html += "                                                <p class=\"msg\"> لا توجد اشعارات" ;
  
                    html += "                                                <\/p>";
                    html += "                                            <\/div>";
                }
                else {
                    html += "                                                <div class=\"avatar\" >";
                    html += "                                                    <img src=\"img\/icon-nav-user.png\" class=\"bg-cover \">";
                    html += "                                                <\/div>";
                    html += "                                                <p class=\"msg\"> There are no notifications";

                    html += "                                                <\/p>";
                    html += "                                            <\/div>";
                }
            }
            $("#div-notification-header").html(html);

        },
        error: function (result) {
            // alert("Error");
        }
    });
}

function loadInbox() {
    $.ajax({
        type: "POST",
        url: "/AjexServer/ajexresponse.aspx/GetNewInbox",
        data: "{}",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            var jsdata = JSON.parse(data.d);
            var html = "";
            for (var i = 0; i < jsdata.length; i++) {
                //var html = "";
                //html += "       <div class=\"nav-dropholder-item\" >";
                //html += "                                        <div class=\"avatar\">";
                //html += "                                            <img src=\"img\/icon-nav-user.png\" class=\"bg-cover \">";
                //html += "                                        <\/div>";
                //html += "                                        <p class=\"msg\"><span class=\"user-name\">زيدان يونس<\/span>هذا النص مثال لى نص هذا";
                //html += "                                            النص مثال لى نص هذا النص مثال لى نص هذا النص مثال لى نص هذا النص مثال لى نص";
                //html += "                                            هذا النص مثال لى نص هذا النص مثال لى نص هذا النص مثال لى نص هذا النص مثال لى";
                //html += "                                            نص <span class=\"remove-item";
                //html += "                                            \"><svg xmlns=\"http:\/\/www.w3.org\/2000\/svg\" width=\"11.963\" height=\"11.963\"";
                //html += "                                                    viewBox=\"0 0 11.963 11.963\">";
                //html += "                                                    <g id=\"Group_21\" data-name=\"Group 21\"";
                //html += "                                                        transform=\"translate(5.981 -3.153) rotate(45)\">";
                //html += "                                                        <line id=\"Line_28\" data-name=\"Line 28\" y2=\"12.918\"";
                //html += "                                                            transform=\"translate(6.459)\" fill=\"none\" stroke=\"#fff\"";
                //html += "                                                            stroke-linecap=\"round\" stroke-width=\"2\"><\/line>";
                //html += "                                                        <line id=\"Line_29\" data-name=\"Line 29\" x2=\"12.918\"";
                //html += "                                                            transform=\"translate(0 6.459)\" fill=\"none\" stroke=\"#fff\"";
                //html += "                                                            stroke-linecap=\"round\" stroke-width=\"2\"><\/line>";
                //html += "                                                    <\/g>";
                //html += "                                                <\/svg><\/span><\/p>";
                //html += "                                        <p class=\"info\"><span class=\"time\"><svg xmlns=\"http:\/\/www.w3.org\/2000\/svg\"";
                //html += "                                                    id=\"Group_2143\" data-name=\"Group 2143\" width=\"19\" height=\"19\"";
                //html += "                                                    viewBox=\"0 0 19 19\">";
                //html += "                                                    <path id=\"Path_6985\" data-name=\"Path 6985\"";
                //html += "                                                        d=\"M9.5,0A9.5,9.5,0,1,0,19,9.5,9.511,9.511,0,0,0,9.5,0Zm0,17.812A8.312,8.312,0,1,1,17.812,9.5,8.322,8.322,0,0,1,9.5,17.812Z\"";
                //html += "                                                        fill=\"#484848\"><\/path>";
                //html += "                                                    <path id=\"Path_6986\" data-name=\"Path 6986\"";
                //html += "                                                        d=\"M241.187,96H240v6.183l3.736,3.736.84-.84-3.388-3.388Z\"";
                //html += "                                                        transform=\"translate(-231.094 -92.438)\" fill=\"#484848\"><\/path>";
                //html += "                                                <\/svg> 8س<\/span><\/p>";
                //html += "                                    <\/div>";

                html += "       <div class=\"nav-dropholder-item\" >";
                html += "                                                <div class=\"avatar\" data-id='" + jsdata[i].ID + "'  style='overflow: inherit!important'>";
                html += "                                                    <img src=\"/Assets/UIKIT/img/inbox.png\" class=\"bg-cover \" >";
                html += "                                                <\/div>";
                if (lang == 'ar') {
                    html += "                                                <p class=\"msg\"><span class='user-name'>" + jsdata[i].docTypDescAr + "</span>" + jsdata[i].docName;
                }
                else {
                    html += "                                                <p class=\"msg\"><span class='user-name'>" + jsdata[i].docTypDesc + "</span>" + jsdata[i].docName;
                }
                html += "                                                    <span class=\"remove-item";
                html += "                                            \">";
                html += "                                                <svg xmlns=\"http:\/\/www.w3.org\/2000\/svg\" width=\"11.963\" height=\"11.963\"";
                html += "                                                    viewBox=\"0 0 11.963 11.963\">";
                html += "                                                    <g id=\"Group_21\" data-name=\"Group 21\"";
                html += "                                                        transform=\"translate(5.981 -3.153) rotate(45)\">";
                html += "                                                        <line id=\"Line_28\" data-name=\"Line 28\" y2=\"12.918\"";
                html += "                                                            transform=\"translate(6.459)\" fill=\"none\" stroke=\"#fff\"";
                html += "                                                            stroke-linecap=\"round\" stroke-width=\"2\">";
                html += "                                                        <\/line>";
                html += "                                                        <line id=\"Line_29\" data-name=\"Line 29\" x2=\"12.918\"";
                html += "                                                            transform=\"translate(0 6.459)\" fill=\"none\" stroke=\"#fff\"";
                html += "                                                            stroke-linecap=\"round\" stroke-width=\"2\">";
                html += "                                                        <\/line>";
                html += "                                                    <\/g>";
                html += "                                                <\/svg><\/span>";
                html += "                                                <\/p>";
                html += "                                                <p class=\"info\">";
                html += "                                                    <span class=\"group\">";
                html += "                                                        <svg xmlns=\"http:\/\/www.w3.org\/2000\/svg\"";
                html += "                                                            id=\"Group_1787\" data-name=\"Group 1787\" width=\"27.34\" height=\"22.534\"";
                html += "                                                            viewBox=\"0 0 27.34 22.534\">";
                html += "                                                            <path id=\"Path_6934\" data-name=\"Path 6934\"";
                html += "                                                                d=\"M255.352,77.4h11.835a.41.41,0,0,0,.41-.41V75.41a.41.41,0,0,0-.41-.41H254.222a.41.41,0,0,0-.334.649l1.13,1.582A.411.411,0,0,0,255.352,77.4Z\"";
                html += "                                                                transform=\"translate(-240.258 -73.398)\" fill=\"#484848\">";
                html += "                                                            <\/path>";
                html += "                                                            <path id=\"Path_6935\" data-name=\"Path 6935\"";
                html += "                                                                d=\"M8.909,45H2.225A2.225,2.225,0,0,0,0,47.225V65.31a2.225,2.225,0,0,0,2.225,2.225H25.116A2.225,2.225,0,0,0,27.34,65.31V52.832a2.225,2.225,0,0,0-2.225-2.225H15.2a2.225,2.225,0,0,1-1.81-.932l-2.674-3.744A2.225,2.225,0,0,0,8.909,45Z\"";
                html += "                                                                transform=\"translate(0 -45)\" fill=\"#484848\">";
                html += "                                                            <\/path>";
                html += "                                                        <\/svg><\/span><span class=\"time\"><svg xmlns=\"http:\/\/www.w3.org\/2000\/svg\"";
                html += "                                                            id=\"Group_2143\" data-name=\"Group 2143\" width=\"19\" height=\"19\"";
                html += "                                                            viewBox=\"0 0 19 19\">";
                html += "                                                            <path id=\"Path_6985\" data-name=\"Path 6985\"";
                html += "                                                                d=\"M9.5,0A9.5,9.5,0,1,0,19,9.5,9.511,9.511,0,0,0,9.5,0Zm0,17.812A8.312,8.312,0,1,1,17.812,9.5,8.322,8.322,0,0,1,9.5,17.812Z\"";
                html += "                                                                fill=\"#484848\">";
                html += "                                                            <\/path>";
                html += "                                                            <path id=\"Path_6986\" data-name=\"Path 6986\"";
                html += "                                                                d=\"M241.187,96H240v6.183l3.736,3.736.84-.84-3.388-3.388Z\"";
                html += "                                                                transform=\"translate(-231.094 -92.438)\" fill=\"#484848\">";
                html += "                                                            <\/path>";
                html += "                                                        <\/svg>";
                html += "                                                            " + jsdata[i].LeftTime +"<\/span>";
                html += "                                                <\/p>";
                html += "                                            <\/div>";

            }
            if (jsdata.length == 0) {
                if (lang == 'ar') {
                    html += "                                                <div class=\"avatar\" >";
                    html += "                                                    <img src=\"img\/icon-nav-user.png\" class=\"bg-cover \">";
                    html += "                                                <\/div>";
                    html += "                                                <p class=\"msg\"> لا يوجد بريد";

                    html += "                                                <\/p>";
                    html += "                                            <\/div>";
                }
                else {
                    html += "                                                <div class=\"avatar\" >";
                    html += "                                                    <img src=\"img\/icon-nav-user.png\" class=\"bg-cover \">";
                    html += "                                                <\/div>";
                    html += "                                                <p class=\"msg\"> There are no Inbox";

                    html += "                                                <\/p>";
                    html += "                                            <\/div>";
                }
            }
            $("#div-inbox-header").html(html);
        },
        error: function (result) {
            // alert("Error");
        }
    });
}