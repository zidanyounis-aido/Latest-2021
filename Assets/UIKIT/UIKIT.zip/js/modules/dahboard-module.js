﻿


var MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

var randomScalingFactor = function () {
    return Math.round(Math.random() * 50);
};









var randomScalingFactor = function () {
    return Math.round(Math.random() * 100);
};




//////// run charts

window.onload = function () {
        fillBarChar();
        fillLineChar();
        loadTodayEvents();
};

function fillLineChar() {
    $.ajax({
        type: "POST",
        url: "/AjexServer/ajexresponse.aspx/fillLineChar",
        data: "{}",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            var jsdata = JSON.parse(data.d);
            var canArr = [];
            for (var i = 0; i < jsdata.length; i++) {
                canArr.push(jsdata[i].Id);
            }
            var config = {
                type: 'line',
                data: {
                    labels: ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30', '31'],
                    datasets: [{
                        label: 'My First dataset',
                        backgroundColor: window.chartColors.blue,
                        borderColor: window.chartColors.blue,
                        data: canArr,
                        fill: true,
                    }]
                },
                options: {
                    responsive: true,
                    tooltips: {
                        mode: 'index',
                        intersect: false,
                    },
                    hover: {
                        mode: 'nearest',
                        intersect: true
                    },
                    scales: {
                        xAxes: [{
                            display: true,
                            scaleLabel: {
                                display: false,
                                // labelString: 'Month'
                            }
                        }],
                        yAxes: [{
                            display: true,
                            scaleLabel: {
                                display: false,
                                // labelString: 'Value'
                            },
                            ticks: {
                                min: 0,
                                max: 50,

                                // forces step size to be 5 units
                                stepSize: 5
                            }
                        }]
                    },
                    legend: {
                        display: false
                    },
                    tooltips: {
                        callbacks: {
                            label: function (tooltipItem) {
                                return tooltipItem.yLabel;
                            }
                        }
                    }
                }
            };
            var ctx1 = document.getElementById('canvasone').getContext('2d');
            window.myLine = new Chart(ctx1, config);
        },
        error: function (result) {
            // alert("Error");
        }
    });
}

function fillBarChar() {
    $.ajax({
        type: "POST",
        url: "/AjexServer/ajexresponse.aspx/fillBarChar",
        data: "{}",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            var jsdata = JSON.parse(data.d);
            var canArr = [];
            var nameArr = [];
            var colorArr = [];
            for (var i = 0; i < jsdata.length; i++) {
                canArr.push(jsdata[i].Id);
                nameArr.push(jsdata[i].Name);
                colorArr.push(jsdata[i].Color);
            }
            var config2 = {
                type: 'doughnut',
                data: {
                    datasets: [{
                        data: canArr,
                        backgroundColor: colorArr,
                        label: 'Dataset 1'
                    }],
                    labels: nameArr
                },
                options: {
                    responsive: true,
                    legend: {
                        position: 'left',
                    },
                    animation: {
                        animateScale: true,
                        animateRotate: true
                    }
                }
            };
            var ctx2 = document.getElementById('canvastwo').getContext('2d');
            window.myDoughnut = new Chart(ctx2, config2);
        },
        error: function (result) {
            // alert("Error");
        }
    });
}

function loadTodayEvents() {
    $.ajax({
        type: "POST",
        url: "/AjexServer/ajexresponse.aspx/GetTodayTasks",
        data: "{}",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            var jsdata = JSON.parse(data.d);
            var eventsTB = [];
            for (var i = 0; i < jsdata.length; i++) {
                eventsTB.push({
                    title: jsdata[i].TaskName
                    , start: jsdata[i].TaskDate
                });
            }
            var calendarEl = document.getElementById('calendar-aside');
            var date = formatDate(new Date());
            var calendarAside = new FullCalendar.Calendar(calendarEl, {
                firstDay: date,
                locale: lang,
                defaultView: 'timeGridDay',
                direction: 'rtl',
                initialView: 'timeGridDay',
                headerToolbar: {
                    left: false,
                    center: 'title',
                    right: false
                },
                height: 'auto',
                navLinks: true, // can click day/week names to navigate views
                editable: true,
                selectable: true,
                selectMirror: true,
                nowIndicator: true,
                events: eventsTB
            });

            calendarAside.render();
        },
        error: function (result) {
            // alert("Error");
        }
    });
}